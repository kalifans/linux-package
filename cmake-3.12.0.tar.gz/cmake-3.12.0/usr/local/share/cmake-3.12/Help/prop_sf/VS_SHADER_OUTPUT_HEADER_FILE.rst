VS_SHADER_OUTPUT_HEADER_FILE
----------------------------

Set filename for output header file containing object code of a ``.hlsl``
source file.
