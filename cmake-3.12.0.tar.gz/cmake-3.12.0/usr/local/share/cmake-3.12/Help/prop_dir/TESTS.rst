TESTS
-----

List of tests.

This read-only property holds a :ref:`;-list <CMake Language Lists>` of tests
defined so far by the :command:`add_test` command.
