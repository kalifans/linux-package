TEST_INCLUDE_FILES
------------------

A list of cmake files that will be included when ctest is run.

If you specify ``TEST_INCLUDE_FILES``, those files will be included and
processed when ctest is run on the directory.
