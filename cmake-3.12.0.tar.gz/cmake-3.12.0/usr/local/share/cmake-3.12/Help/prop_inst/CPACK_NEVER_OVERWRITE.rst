CPACK_NEVER_OVERWRITE
---------------------

Request that this file not be overwritten on install or reinstall.

The property is currently only supported by the WIX generator.
