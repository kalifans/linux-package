PROJECT_VERSION_MINOR
---------------------

Second version number component of the :variable:`PROJECT_VERSION`
variable as set by the :command:`project` command.
