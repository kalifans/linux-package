.. cmake-module:: ../../Modules/FindwxWidgets.cmake
