.. cmake-module:: ../../Modules/FindPython2.cmake
