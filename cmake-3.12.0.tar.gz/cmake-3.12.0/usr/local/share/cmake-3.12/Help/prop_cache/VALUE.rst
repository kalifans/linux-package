VALUE
-----

Value of a cache entry.

This property maps to the actual value of a cache entry.  Setting this
property always sets the value without checking, so use with care.
