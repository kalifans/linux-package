function handle(r)
   r:puts(r.method)
end
