function handle(r)
  r:puts(apache2.version)
end
