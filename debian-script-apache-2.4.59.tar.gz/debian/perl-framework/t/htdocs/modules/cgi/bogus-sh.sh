#!/bin/sh
echo sh cgi
