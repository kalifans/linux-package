#!/bin/sh
echo Content-type: text/plain
echo
echo $PATH_INFO
