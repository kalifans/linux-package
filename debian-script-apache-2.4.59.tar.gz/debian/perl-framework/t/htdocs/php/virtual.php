before <?php virtual("multiviews/file"); ?> after
