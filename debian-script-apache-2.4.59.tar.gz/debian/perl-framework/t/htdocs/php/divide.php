<?php $a=27; $b=3; $c=3; $d=$a/$b/$c; echo $d?>
