<?php
    foreach ($_SERVER as $key => $value) {
        echo "$key=$value\n";
    }