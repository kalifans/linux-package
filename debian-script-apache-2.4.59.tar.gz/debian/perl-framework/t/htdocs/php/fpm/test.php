<?php var_export($_SERVER)?>
