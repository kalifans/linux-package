<?php
	for($i=0;$i<$_SERVER["argc"];$i++) {
                echo "$i: ".$_SERVER["argv"][$i]."\n";
        }
?>
