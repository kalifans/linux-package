<?php putenv("FOO_FEE=HelloWorld");
echo getenv("FOO_FEE"); ?>
