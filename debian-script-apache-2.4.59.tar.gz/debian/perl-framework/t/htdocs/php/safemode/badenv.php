<?php putenv("FISH=HelloWorld");
echo getenv("FISH"); ?>
