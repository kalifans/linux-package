<?php readfile("hello.txt"); ?>
