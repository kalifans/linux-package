<?php  old_function Test $b (
                $b++;
                return($b);
        );
        $a = Test(1);
        echo $a?>

