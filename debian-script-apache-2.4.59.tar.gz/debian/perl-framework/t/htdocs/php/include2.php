<?php
        include "include2.inc";
        MyFunc("Hello");
?>
